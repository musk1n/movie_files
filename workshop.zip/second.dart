import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SecondScreen extends StatefulWidget {
  final Map<String, dynamic> movie;

  const SecondScreen({Key? key, required this.movie}) : super(key: key);

  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  late String description = '';

  @override
  void initState() {
    super.initState();
    fetchMovieDetails();
  }

  Future<void> fetchMovieDetails() async {
    final String apiKey = '33eeb7f10cc8f6fe332d9dfe65281f4c'; 
    final String movieId = widget.movie['id'].toString(); 
    final uri = Uri(
      host: "api.themoviedb.org",
      path: "/3/movie/$movieId", 
      queryParameters: {
        "api_key": apiKey,
      },
    );
    final http.Response response = await http.get(uri);

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      setState(() {
        description = data['overview'] ?? 'No description available';
      });
    } else {
      setState(() {
        description = 'Failed to fetch description. Status code: ${response.statusCode}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    String title = widget.movie['title'] ?? 'Movie Title';
    String imageUrl = widget.movie['image_url'] ?? '';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.purple),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 10),
            child: Container(
              height: 20,
              color: Colors.white,
            ),
          ),
          Container(
            height: 200,
            width: double.infinity,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 16), 
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage("https://image.tmdb.org/t/p/w500$imageUrl"),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Colors.purple,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    description,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}