import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:ui';
import "package:http/http.dart" as http;
import 'package:flutter_app/second.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
      scrollBehavior: ScrollBehavior().copyWith(dragDevices: {
        PointerDeviceKind.mouse,
        PointerDeviceKind.trackpad,
        PointerDeviceKind.touch,
        PointerDeviceKind.stylus,
      }),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, String>> nowPlayingMovies = [];
  List<Map<String, String>> trendingMovies = [];
  List<Map<String, String>> topRatedMovies = [];

  void getNowPlayingMovies() async {
    final uri = Uri(
      host: "api.themoviedb.org",
      path: "/3/movie/now_playing",
      queryParameters: {
        "api_key": "33eeb7f10cc8f6fe332d9dfe65281f4c",
      },
    );
    final res = await http.get(uri);
    final body = jsonDecode(res.body);
    final newMovies = body['results'] as List;
    for (int i = 0; i < newMovies.length; i++) {
      final movie = newMovies[i];
      Map<String, String> movieMap = {
        "id": movie['id'].toString(),
        "title": movie['title'],
        "image_url": movie['backdrop_path'],
      };
      nowPlayingMovies.add(movieMap);
    }
    setState(() {});
  }

  void getTrendingMovies() async {
    final uri = Uri(
      host: "api.themoviedb.org",
      path: "/3/trending/movie/week",
      queryParameters: {
        "api_key": "33eeb7f10cc8f6fe332d9dfe65281f4c",
      },
    );
    final res = await http.get(uri);
    final body = jsonDecode(res.body);
    final newMovies = body['results'] as List;
    for (int i = 0; i < newMovies.length; i++) {
      final movie = newMovies[i];
      Map<String, String> movieMap = {
        "id": movie['id'].toString(),
        "title": movie['title'],
        "image_url": movie['backdrop_path'],
      };
      trendingMovies.add(movieMap);
    }
    setState(() {});
  }

  void getTopRatedMovies() async {
    final uri = Uri(
      host: "api.themoviedb.org",
      path: "/3/movie/top_rated",
      queryParameters: {
        "api_key": "33eeb7f10cc8f6fe332d9dfe65281f4c",
      },
    );
    final res = await http.get(uri);
    final body = jsonDecode(res.body);
    final newMovies = body['results'] as List;
    for (int i = 0; i < newMovies.length; i++) {
      final movie = newMovies[i];
      Map<String, String> movieMap = {
        "id": movie['id'].toString(),
        "title": movie['title'],
        "image_url": movie['backdrop_path'],
      };
      topRatedMovies.add(movieMap);
    }
    setState(() {});
  }

  @override
  void initState() {
    getNowPlayingMovies();
    getTrendingMovies();
    getTopRatedMovies();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          "Movie App",
          style: TextStyle(
            color: Colors.purple,
            fontWeight: FontWeight.bold,
          ),
        ),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Now Playing",
                style: TextStyle(
                  color: Colors.purple,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Container(
                height: 160,
                child: ListView.builder(
                  itemCount: nowPlayingMovies.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    Map<String, String> movie = nowPlayingMovies[index];
                    String url = movie['image_url'].toString();
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => SecondScreen(movie: movie)),
                        );
                      },
                      child: Container(
                        width: 120,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                               Container(
                                height: 120,
                                width: 90,
                                margin: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                ),
                                child:ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                  child: Image.network(
                                    "https://image.tmdb.org/t/p/w500$url",
                                    fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Text(
                              movie['title'].toString(),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 20),
              Text(
                "Trending",
                style: TextStyle(
                  color: Colors.purple,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Container(
                height: 160,
                child: ListView.builder(
                  itemCount: trendingMovies.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    Map<String, String> movie = trendingMovies[index];
                    String url = movie['image_url'].toString();
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => SecondScreen(movie: movie)),
                        );
                      },
                      child: Container(
                        width: 120,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                              Container(
                                height: 120,
                                width: 90,
                                margin: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                ),
                                child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  "https://image.tmdb.org/t/p/w500$url",
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Text(
                              movie['title'].toString(),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 20),
              Text(
                "Top Rated",
                style: TextStyle(
                  color: Colors.purple,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Container(
                height: 160,
                child: ListView.builder(
                  itemCount: topRatedMovies.length,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) {
                    Map<String, String> movie = topRatedMovies[index];
                    String url = movie['image_url'].toString();
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => SecondScreen(movie: movie)),
                        );
                      },
                      child: Container(
                        width: 120,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                              Container(
                                height: 120,
                                width: 90,
                                margin: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                ),
                                child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  "https://image.tmdb.org/t/p/w500$url",
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Text(
                              movie['title'].toString(),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}